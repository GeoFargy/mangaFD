"""

    This script runs the bayesian optimization to run experiments and look for effective hyperparameters. 

    Dataset used for fine-tuning: 
        Manga109, but you can change using another yaml in data_file
    
    Model:
        YOLO-12S using pre-trained MangaFD (yolo12s_manga.pt). 
        Other models suggested very similar values.

    Hyperparamenters: 
        Please see results below.
    
    
"""

from ultralytics import YOLO
import optuna
import os
import torch

# Set CUDA device
device_cuda = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')

# Set directories

base_dir = os.path.dirname(os.path.abspath(__file__))  
parent_dir = os.path.abspath(os.path.join(base_dir, os.pardir))
data_file = os.path.join(base_dir, "Manga109.yaml")  
model_path = os.path.join(base_dir, "yolo12s_manga.pt")  
results_dir = os.path.join(base_dir, "results")  

def objective(trial):
    
    lr0 = trial.suggest_float("lr0", 1e-5, 1e-1)
    lrf = trial.suggest_float("lrf", 0.01, 1.0)
    momentum = trial.suggest_float("momentum", 0.6, 0.98)
    weight_decay = trial.suggest_float("weight_decay", 0.0, 0.001)
    fr = trial.suggest_int("freeze", 0, 10)
    
    
    model = YOLO(model_path)
    
    
    results = model.train(
        data=data_file,
        epochs=100,
        optimizer="auto",
        classes=[0],
        imgsz=640,
        device=device_cuda,  
        batch=8,
        lr0=lr0,
        lrf=lrf,
        momentum=momentum,
        weight_decay=weight_decay,
        verbose=False,
        freeze=fr
    )

    
    map50 = results.box.map50 # Here we are defining that we want to optimize for the map50.
    return map50  


# We release also a simple function to load parameters:

def load_params(path : str):
    
    best_params = {}
    
    with open(path, 'r') as f:
        for line in f:
            key, value = line.strip().split(': ')
            best_params[key] = float(value)

    print("loaded from files:", best_params)


if __name__ == "__main__":
    
    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=50)
    
    
    print("Optimal parameters found:")
    print(study.best_params)


    # We get the best values
    best_params = study.best_params

# Save parameters in a text file
    with open('best_params.txt', 'w') as f:
        for key, value in best_params.items():
            f.write(f"{key}: {value}\n")

    print("Parameters optimized found in 'best_params.txt'")
