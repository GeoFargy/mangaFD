"""

    This script runs the fine-tuning using bayesian optimized hyperparameters.

    Dataset used for fine-tuning: 
        Manga109.
    
    Model:
        YOLO-12S using bilinear modules

    Hyperparamenters: 
        Please see results below.     
    
"""

import matplotlib.pyplot as plt
from ultralytics import YOLO
import os
import torch

# Set cuda device
device = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')

# Set directory

base_dir = os.path.dirname(os.path.abspath(__file__))  
parent_dir = os.path.abspath(os.path.join(base_dir, os.pardir))
data_file = os.path.join(base_dir, "Manga109.yaml")  
model_path = os.path.join(parent_dir, "yolo12s_bilinear.yaml")  
results_dir = os.path.join(parent_dir, "results", "results_109_bilinear_b")  


model = YOLO(model_path)



results = model.train(
    data=data_file,
    epochs=350,  
    device=device,  
    classes=[0],
    batch=16,  
    optimizer='auto',
    augment=True,
    amp=True,
    plots=True,
    momentum = 0.9779661779990504,
    lr0 = 0.05777687126887075, 
    lrf = 0.9749324626213757,
    freeze=[0],
    patience=100,
    weight_decay = 0.00030150721554585386,
    project=results_dir  
    )

print(f"Training completed. Results saved in {results_dir}.")
