"""

    This script runs the fine-tuning using bayesian optimized hyperparameters, with YOLO-12S re-trained on MangaFD.

    Dataset used for fine-tuning: 
        Manga109.
    
    Model:
        YOLO-12S re-trained on MangaFD (yolo12s_manga.pt)

    Hyperparamenters: 
        Please see results below. 
        The difference with the training109_fd_b_400.py file is that this time is trained with 600 epochs.
    
    
"""

import matplotlib.pyplot as plt
from ultralytics import YOLO
import os
import torch

# Set cuda device
device = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')

# Set directory

base_dir = os.path.dirname(os.path.abspath(__file__))  
parent_dir = os.path.abspath(os.path.join(base_dir, os.pardir))
data_file = os.path.join(base_dir, "Manga109.yaml")  
model_path = os.path.join(parent_dir, "models", "yolo12s_manga.pt")  
results_dir = os.path.join(parent_dir, "results", "results_109_fd_b_600")  


model = YOLO(model_path)

# The momentum, lr0, lrf and weight_decay are taken from the bayesian optimization


results = model.train(
    data=data_file,
    epochs=600,  
    device=device,  
    classes=[0],
    batch=16,  
    optimizer='auto',
    augment=True,
    amp=True,
    plots=True,
    momentum = 0.9779661779990504,
    lr0 = 0.05777687126887075, 
    lrf = 0.9749324626213757,
    freeze=[0],
    patience=100,
    weight_decay = 0.00030150721554585386,
    project=results_dir  
    )

print(f"Training completed. Results saved in {results_dir}.")
