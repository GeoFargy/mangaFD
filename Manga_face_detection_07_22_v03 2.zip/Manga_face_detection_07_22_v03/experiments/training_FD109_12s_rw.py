"""

    This script runs the fine-tuning using both datasets.

    Dataset used for fine-tuning: 
        Both Manga109 and MangaFD.
    
    Model:
        YOLO-12S using random weights (yolo12s_rw.py)

    Hyperparamenters: 
        Please see results below.
    
    
"""



from ultralytics import YOLO
import os
import torch

# Set cuda device
device = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')

# Set directory
base_dir = os.path.dirname(os.path.abspath(__file__))  
parent_dir = os.path.abspath(os.path.join(base_dir, os.pardir))
data_file = os.path.join(base_dir, "MangaFD109.yaml")  
model_path = os.path.join(base_dir, "yolov12s_rw.yaml")  
results_dir = os.path.join(parent_dir, "results", "results_FD109_rw")  


model = YOLO(model_path)


results = model.train(
    data=data_file,
    epochs=250,  
    device=device,  
    classes=[0],
    batch=8,  
    optimizer='auto',
    augment=True,
    amp=True,
    plots=True,
    freeze=[0],
    patience=50,
    project=results_dir  
)

print(f"Training completed. Results saved in {results_dir}.")
