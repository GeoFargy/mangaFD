"""

    This script runs the fine-tuning using for body detection on Manga109.

    Dataset used for fine-tuning: 
        Manga109.
    
    Model:
        YOLO-12S using pre-trained COCO(yolo12s.py)

    Hyperparamenters: 
        Please see results below.
    
    
"""


from ultralytics import YOLO
import os
import torch

# Set cuda device
device = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')

# Set directory

base_dir = os.path.dirname(os.path.abspath(__file__))  
parent_dir = os.path.abspath(os.path.join(base_dir, os.pardir))
data_file = os.path.join(base_dir, "Manga109_body.yaml")  
model_path = os.path.join(parent_dir, "models", "yolo12s.pt")  
results_dir = os.path.join(parent_dir, "results", "results_body")  


model = YOLO(model_path)


results = model.train(
    data=data_file,
    epochs=350,  
    device=device,  
    classes=[0],
    batch=16,  
    optimizer='auto',
    augment=True,
    amp=True,
    plots=True,
    freeze=[0],
    patience=100,
    project=results_dir,  
    name="body_109_nonFD_coco"  
)

print(f"Training completed. Results saved in {results_dir}.")
